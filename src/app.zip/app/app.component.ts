import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Allow Fense!';
   lat: number =  -8.05428;
  	lng: number = -34.8813;
}
