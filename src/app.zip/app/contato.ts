export interface Contato {
	id: number;
	nome: string;
	email: string;
	telefone: string;
	assunto: string;
	mensagem: string;
}
